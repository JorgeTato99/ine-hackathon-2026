# Traza Cívica · Mapa de escenarios · Reto 2

Datos: resultados-1.6. Fuente científica: 7ff4ca3cfbdc0b4f90d1df44be4b4acf00e61fd7.
Consulta interactiva: https://traza-civica.jorgetato.com/

## Contenido y apertura

- `mapa/municipios.gpkg`: mapa portable con 2,478 geometrías y los cinco escenarios.
- `base-datos/`: los CSV, XLSX, diccionario y LEEME originales de Sofía.
- `metadatos.json`: variables, unidades, fuentes y límites del análisis.
- `controles.json`: cifras con las que se comprobó la publicación.
- `MANIFIESTO.json`: versión, procedencia, tamaños y SHA-256 de los archivos.

El mapa GPKG puede consultarse sin Internet con QGIS u otro programa compatible
con GeoPackage. Abrir `mapa/municipios.gpkg` y elegir la capa `resultados_2027`.
Las coordenadas usan EPSG:4326 y `cvegeo` es texto de cinco dígitos.

Para comparar sin y con intervención en QGIS:

1. Duplicar la capa para tener dos copias del mismo territorio.
2. En Simbología, elegir Categorizado y el campo
   `nac_estimado_int_ninguna_riesgo` en la primera copia.
3. En la segunda, elegir `nac_estimado_int_combinada_riesgo`.
4. Usar rojo para `alto`, amarillo para `medio`, verde para `bajo` y gris para
   NULL (sin dato). Conservar ese significado en ambas capas.
5. Consultar los campos con sufijos `part_pred`, `part_pred_inf` y
   `part_pred_sup` para la cifra central y el rango; los valores van de 0 a 1.

Para otra intervención, cambiar `combinada` por `retener_primerizos`,
`jovenes_20_29` o `credencializacion`. El nivel nacional base es único y estimado
(51.4 %). La URL ofrece fichas municipales, pronóstico e histórico.

## Cómo interpretar los datos

Información agregada, sin datos personales. Hay 2,477 municipios con resultados;
Villa de Pozos (24059) tiene geometría pero no estimación. NULL o vacío nunca
equivale a cero. Un cero histórico identificado como falta de casillas significa
que no se pudo votar; revisar `alerta_sin_casilla` y los metadatos.

2027 es pronóstico condicionado a supuestos, no un resultado observado.
La intervención es **supuesto, no efecto medido**: no demuestra eficacia de
una campaña. El semáforo compara riesgo; no decide por sí solo la prioridad.
La tasa de homicidios en logaritmo sí es una variable del modelo. Los otros datos
de seguridad y la comparación estatal INEGI–SESNSP son contexto histórico.
La validación es retrospectiva con datos revisados; los rangos y la frecuencia
simulada de rojo son aproximaciones, sin garantía uniforme para 2027.
Si `motivo` contiene `intervencion_parcial`, la acción se calculó solo con los
componentes conocidos. Sin dato S3 no se suman votos ni personas por S3. El GPKG
conserva motivo y estado de estimación para cada escenario.

En `historia_municipal.csv` la participación va de 0 a 100; en las tablas de
2027 y el GPKG va de 0 a 1. Leer `base-datos/LEEME.md` y el diccionario antes
de combinar archivos. Las 15 ausencias de brecha joven están vacías, no son cero.
En esos mismos municipios faltan los conteos por edad de 2024 y los componentes
S1/S2; en la versión vigente se conservan vacíos. Los totales de personas suman solo
los datos disponibles. Esto no elimina sus pronósticos ni el componente S3.

## Alcance de este paquete

Este es el componente del mapa y su base de datos para incorporar al ZIP final
del equipo. No contiene el reporte metodológico/preventivo, la presentación ni
las cartas firmadas. El nombre del ZIP final debe usar el nombre registrado
del equipo y el eje del concurso. Este paquete no fija la licencia de la obra;
la consulta sobre cesión y difusión corresponde resolverla con el INE.

Fuentes y créditos: INE, INEGI y las demás fuentes declaradas en metadatos.
La geometría está simplificada para visualización; no sustituye límites oficiales.
